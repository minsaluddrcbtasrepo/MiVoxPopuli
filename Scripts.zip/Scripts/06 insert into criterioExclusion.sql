	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,1)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,2)				

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,3)					
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,4)			
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,5)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,5)			
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (6,5)

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,6)		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,6)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,7)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,8)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,9)					
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,10)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,11)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,12)					
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,13)				

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,14)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,14)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,14)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,15)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,16)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,16)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,16)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,17)					
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,18)			
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,19)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,19)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,20)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,21)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,22)		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,22)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,23)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,24)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,25)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,26)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,27)					
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,28)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,28)			
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,29)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,29)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,30)		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,30)			
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,31)				

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,32)					
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,33)				
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,34)				
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,35)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,35)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,36)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,37)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,38)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,39)					
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,40)			
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,41)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,41)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,42)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,43)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,44)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,45)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,46)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,46)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,46)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,47)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,48)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,49)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,50)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,50)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,50)			
					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,52)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,52)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,52)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,53)					
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,54)				

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,55)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,56)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,57)					
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,58)				

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,59)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,60)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,61)					
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,62)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,63)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,63)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,63)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,64)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,64)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,64)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,65)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,66)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,67)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,68)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,69)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,70)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,71)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,72)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,73)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,74)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,75)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,76)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,77)					
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,78)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,78)		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (5,78)	

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,79)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,80)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,81)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,82)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,83)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,84)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,85)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,86)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,87)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,88)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,89)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,90)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,91)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,92)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,93)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,94)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,95)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,96)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,97)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,98)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,99)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,100)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,101)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,102)					
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,103)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,103)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (4,103)		
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,104)			
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,105)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,105)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,106)			
		
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,107)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (4,107)		

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,108)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,108)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,108)			
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,109)				
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,110)				
	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (2,111)	
insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (3,111)			

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,112)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,113)					

insert into EXCLUSIONES.CriterioExcIusion (idCriterio,IdTecnoIogiaExcluida) values (1,114)					
